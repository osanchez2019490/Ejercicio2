public class Cuerda extends Instrumento {
    private int numeroDeCuerdas;

    public Cuerda(String nombre, double precio, String marca, int numeroDeCuerdas) {
        super(nombre, precio, marca);
        this.numeroDeCuerdas = numeroDeCuerdas;
    }

    public int getNumeroDeCuerdas() {
        return numeroDeCuerdas;
    }

    public void setNumeroDeCuerdas(int numeroDeCuerdas) {
        this.numeroDeCuerdas = numeroDeCuerdas;
    }

    @Override
    public void tocar() {
        System.out.println("Tocando el instrumento de cuerda " + getNombre() + ". Suena suave.");
    }
}
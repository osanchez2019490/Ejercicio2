public abstract class Instrumento {

    private String nombre;
    private double precio;
    private String marca;

   public Instrumento (String nombre, double precio, String marca) {
       this.nombre = nombre;
       setPrecio(precio);
       this.marca = marca;
   }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo.");
        }
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public abstract void tocar();
}

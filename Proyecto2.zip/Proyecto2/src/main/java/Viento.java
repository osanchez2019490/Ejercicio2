public class Viento extends Instrumento {

    private String tipoDeBoquilla;

    public Viento(String nombre, double precio, String marca, String tipoDeBoquilla) {
        super(nombre, precio, marca);
        this.tipoDeBoquilla = tipoDeBoquilla;

    }

    public String getTipoDeBoquilla() {
        return tipoDeBoquilla;
    }

    public void setTipoDeBoquilla(String tipoDeBoquilla) {
        this.tipoDeBoquilla = tipoDeBoquilla;
    }

    @Override
    public void tocar(){
        System.out.println("Tocando el instrumento de viento " + getNombre() + ". Suena fuerte.");
    }
}

public class main {
    public static void main(String[] args) {
        Tienda tienda = new Tienda();

        Cuerda guitarra = new Cuerda("Guitarra", 1500.00, "Yamaha", 6);
        Viento trompeta = new Viento("Trompeta", 800.00, "Bach", "Estándar");
        Percusion tambor = new Percusion("Tambor", 300.00, "Pearl", "Sintético");

        tienda.agregarInstrumento(guitarra);
        tienda.agregarInstrumento(trompeta);
        tienda.agregarInstrumento(tambor);

        tienda.mostrarInstrumentos();

    }
}

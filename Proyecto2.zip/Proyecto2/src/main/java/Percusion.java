public class Percusion extends Instrumento {

    private String tipoDeParches;

    public Percusion (String nombre, double precio, String marca, String tipoDeParches) {
        super(nombre, precio, marca);
        this.tipoDeParches = tipoDeParches;
    }

    public String getTipoDeParches() {
        return tipoDeParches;
    }

    public void setTipoDeParches(String tipoDeParches) {
        this.tipoDeParches = tipoDeParches;
    }

    @Override
    public void tocar() {
        System.out.println("Tocando el instrumento de percusión " + getNombre() + ". Suena rítmico.");
    }
}


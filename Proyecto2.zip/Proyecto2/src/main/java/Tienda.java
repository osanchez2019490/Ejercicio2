import java.util.ArrayList;
import java.util.List;

public class Tienda {
    private List<Instrumento> instrumentos;

    public Tienda(){
        instrumentos = new ArrayList<>();
    }

    public void agregarInstrumento(Instrumento instrumento) {
        instrumentos.add(instrumento);
    }

    public void mostrarInstrumentos() {
        for (Instrumento instrumento : instrumentos) {
            instrumento.tocar();
        }
    }}
